package es.ies.puerto;

import java.time.LocalDate;

/**
Ejercicio 8: Calcular cuántos días han pasado desde el inicio del anio hasta
una fecha dada
@author prorix
@version 1.0.0
*/
public class Ejercicio8 {

    /**
     * Metodo para calcular cuantos dias an transcurrido desde el uno de
     * enero de ese mismo anio hasta la fecha dada
     * @param fecha a calcular
     * @return cantidad de dias
     */
    public static long diasDesdeInicioDelanio(LocalDate fecha) {
        if (fecha == null) return -1;
        return fecha.getDayOfYear();
    }
}
