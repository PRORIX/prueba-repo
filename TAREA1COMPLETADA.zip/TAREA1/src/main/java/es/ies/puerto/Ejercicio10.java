package es.ies.puerto;

import java.time.LocalDate;

/**
Ejercicio 10: Calcular la fecha de "San Valentín" del próximo anio
@author prorix
@version 1.0.0
*/
public class Ejercicio10 {
    
    /**
     * Metodo para calcular la diferencia en dias entre dos fechas
     * @param fecha1 fecha de inicio a contar
     * @param fecha2 fecha fin a contar
     * @return cantidad de dias
     */
    public static long calcularDiferenciaEnDias(LocalDate fecha1, LocalDate fecha2) {
        if (fecha1 == null || fecha2 == null) return -1;
        return fecha2.compareTo(fecha1);
    }
}
