package es.ies.puerto;

import java.time.LocalDate;
import java.time.Month;

/**
Ejercicio 2: Calcular el número de días de un mes específico
@author prorix
@version 1.0.0
*/
public class Ejercicio2 {
    /**
     * Funcion para calcular el numero de dias que tiene el mes de una fecha
     * @param anio de la fecha
     * @param mes de la fecha
     * @return numero de dias del mes
     */
    public static int obtenerDiasDelMes(int anio, Month mes) {
        if (anio < 1 || mes == null) return -1;
        LocalDate localDate = LocalDate.of(anio, mes.getValue(), 0);
        int numMes = localDate.getMonthValue();
        switch (numMes) {
            case 1, 3, 5, 7, 8, 10, 12: return 31;
            case 4, 6, 9, 11: return 30;
            case 2:
                if ((anio%4 == 0 && anio%100 != 0) || anio%400 == 0) {
                    return 29;
                }
                return 28;
            default:
                return -1;
        }
    }
}
