package es.ies.puerto;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;

/**
Ejercicio1: Verificar si una fecha es un viernes 13
@author prorix
@version 1.0.0
*/
public class Ejercicio1 {
    /**
     * Funcion que comprueba si una fecha es viernes 13
     * @param fechaStr String con formato fecha
     * @return true/false
     */
    public static boolean esViernes13(String fechaStr) {
        if(fechaStr == null || fechaStr.isEmpty()) return false;
        LocalDate localDate = LocalDate.parse(fechaStr);
        if (localDate.getDayOfMonth() == 13 && localDate.getDayOfWeek().equals(DayOfWeek.FRIDAY)) {
            return true;
        }
        return false;
    }
}
