package es.ies.puerto;

import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.Set;
import java.util.HashSet;
import java.sql.Date;

/**
Ejercicio 4: Determinar si una fecha es un "Día Festivo Nacional"
@author prorix
@version 1.0.0
*/
public class Ejercicio4 {
    /**
     * Metodo para determinar si una fecha dada es dia festivo
     * @param fecha a comprobar
     * @return true/false
     */
    public static boolean esDiaFestivoNacional(LocalDate fecha) {
        if (fecha == null) {
            return false;
        }
        if (fecha.getMonth().equals(Month.DECEMBER) && fecha.getDayOfMonth() == 25) {
            return true;
        }
        if (fecha.getMonth().equals(Month.JANUARY) && fecha.getDayOfMonth() == 1) {
            return true;
        }
        return false;
    }
}
