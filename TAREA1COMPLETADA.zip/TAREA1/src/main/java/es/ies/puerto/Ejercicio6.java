package es.ies.puerto;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.Year;

/**
Ejercicio 6: Calcular la cantidad de fines de semana (sábados y domingos) en
un mes
@author prorix
@version 1.0.0
*/
public class Ejercicio6 {

    /**
     * Metodo para calcular la cantidad que fines de semana que ocurren en ese mes
     * @param anio a calcular
     * @param mes del anio a calcular a calcular
     * @return cantidad de fines de semana
     */
    public static int obtenerFinesDeSemana(int anio, Month mes) {
        if (anio < 1 || mes == null) return -1;
        LocalDate localDate = LocalDate.of(anio, mes, 1);
        int finesSemana = 0;
        for (int i = 0; i < mes.length(Year.isLeap(anio)); i++) {
            if (localDate.getDayOfWeek().equals(DayOfWeek.SATURDAY) || localDate.getDayOfWeek().equals(DayOfWeek.SUNDAY)) {
                finesSemana++;
            }
            localDate = localDate.plusDays(1);
        }
        return finesSemana;
    }
}
