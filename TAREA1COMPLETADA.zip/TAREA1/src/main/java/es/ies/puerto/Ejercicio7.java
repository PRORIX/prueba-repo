package es.ies.puerto;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.Year;
import java.time.temporal.TemporalAdjusters;

/**
Ejercicio 7: Calcular la fecha exacta para el Día de la Madre (en el país
correspondiente)
@author prorix
@version 1.0.0
*/
public class Ejercicio7 {

    /**
     * Funcion para calcular el dia de la madre en cualqueir anio
     * @param anio a calcular
     * @return
     */
    public static LocalDate obtenerDiaDeLaMadre(int anio) {
        if (anio < 1) {
            return null;
        }
        LocalDate localDate = LocalDate.of(anio,Month.MAY,1);
        int sabados = 0;
        for (int i = 0; i < Month.MAY.length(Year.isLeap(anio)); i++) {
            if (localDate.getDayOfWeek().equals(DayOfWeek.SATURDAY)) {
                sabados++;
            }
            localDate = localDate.plusDays(1);
            if (sabados == 2) {
                return localDate;
            }
        }
        return null;
    }
}