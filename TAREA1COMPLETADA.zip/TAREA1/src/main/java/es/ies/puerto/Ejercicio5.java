package es.ies.puerto;

import java.time.LocalDate;

/**
Ejercicio 5: Encontrar el día de la semana de la fecha más lejana en el futuro
@author prorix
@version 1.0.0
*/
public class Ejercicio5 {

    /**
     * Metodo para calcular el dia de la semana que ocurrira despues d eusmar n dias a la fecha actual
     * @param fecha inicial
     * @param dias a sumar
     * @return
     */
    public static String obtenerDiaDeLaSemanaEnElFuturo(LocalDate fecha, int dias) {
        if (fecha == null) {
            return null;
        }
        fecha = fecha.plusDays(dias);
        return fecha.getDayOfWeek().toString();
    }
}
