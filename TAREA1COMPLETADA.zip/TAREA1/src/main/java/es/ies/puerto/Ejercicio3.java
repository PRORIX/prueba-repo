package es.ies.puerto;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;

/**
Ejercicio 3: Calcular la fecha del último viernes de un mes
@author prorix
@version 1.0.0
*/
public class Ejercicio3 {
    /**
     * Metodo para calcular la fecha del ultimo viernes del mismo mes y anio
     * @param anio de la fecha
     * @param mes de la fecha
     * @return fecha del ultimo viernes
     */
    public static LocalDate obtenerUltimoViernes(int anio, Month mes) {
        if(mes == null || anio < 1 || mes.getValue() < 1 || mes.getValue() > 12) return null;
        LocalDate fechaActual;
        for (int dia = mes.maxLength(); dia > 0 ; dia--) {
            fechaActual = LocalDate.of(anio, mes.getValue(), dia);
            if (fechaActual.getDayOfWeek().equals(DayOfWeek.FRIDAY)) {
                return LocalDate.of(anio, mes.getValue(), dia);
            }
        }
        return null;
    }
}
