package es.ies.puerto;

import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.time.DayOfWeek;

/**
Ejercicio 9: Determinar si una fecha es el último día del anio
@author prorix
@version 1.0.0
*/
public class Ejercicio9 {

    /**
     * Metodo para determinar el primer lunes del mes proporcionado
     * @param anio para calcular
     * @param mes para calcular
     * @return primer lunes del mes
     */
    public static LocalDate obtenerPrimerLunesDelMes(int anio, int mes) {
        if (anio < 1 || mes < 1) {
            return null;
        }
        LocalDate fecha = LocalDate.of(anio, mes, 1);
        for (int i = 0; i < fecha.lengthOfMonth(); i++) {
            if (fecha.getDayOfWeek().equals(DayOfWeek.MONDAY)) {
                return fecha;
            }
            fecha = fecha.plusDays(1);
        }
        return null;
    }
}
